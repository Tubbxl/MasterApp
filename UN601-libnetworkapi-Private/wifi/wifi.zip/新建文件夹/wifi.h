#ifndef __WIFI_H__
#define __WIFI_H__

#include "Dll_api.h"

int Dll_WifiScan(WIFI_STRUCT *network);
int Dll_ConnectNetworkNoKey(unsigned char *SSID);
int Dll_ConnectNetworkHaveKey(unsigned char *SSID,unsigned char *key);
int Dll_SetIP(uchar *ip,uchar *mask,uchar *gateway);
int Dll_Dhcp();
int Dll_GetNetworkStatus(unsigned char *network);
int Dll_CloseNetwork();
int Dll_SocketOpen(uchar *address,int port,int *sock);
int Dll_SocketClose(int sockfd);
int Dll_SocketRecv(int sockfd,uchar *buf,int maxLen, int *recvLen,int timeout_sec);
int Dll_SocketSend(int sockfd,uchar *buf,int len);

#endif

