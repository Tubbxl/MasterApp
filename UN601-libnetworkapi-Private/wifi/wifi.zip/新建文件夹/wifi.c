
#include <sys/types.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <termios.h>
#include <fcntl.h>
#include <pthread.h>
#include <syslog.h>
#include <signal.h>
#include <netdb.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <pthread.h>

#include <unistd.h>
#include <sys/wait.h>

#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <ctype.h>
#include <limits.h>
#include <stdarg.h>
#include <assert.h>
#include <stdint.h>
#include <errno.h>

#include <net/if.h>
#include <linux/if_ether.h>

 #include <unistd.h>
#include "wifi.h"


int Dll_WifiOpen()
{
	system("ifconfig wlan0 up");
}
int Dll_WifiClose()
{
	system("ifconfig wlan0 down");
}


int Dll_WifiScan(WIFI_STRUCT *network)
{
	char buf[1000]={0};
	FILE *fp;
	BYTE first=0;
	int SumOfNetwork=0,k;
	printf("iwlist wlan0 scan...\n");
	sprintf(buf,"iwlist wlan0 scan >/tmp/dat.dat");
	system(buf);
	fp=fopen("/tmp/dat.dat","r");	
	while(fscanf(fp,"%s",buf)!=EOF)
	{
		
		if(buf[0]==0)continue;
		if(memcmp(buf,"ESSID:\"",7)==0 && buf[7]!='\"')
		{
			memcpy(network[SumOfNetwork].SSID,buf+7,strlen(buf)-8);
			network[SumOfNetwork].SSID[strlen(buf)-8]=0;
			network[SumOfNetwork].mode = 0;
		}
		if(!memcmp(buf,"level",5)){
			first=!first;
			if(first!=0) strcpy(network[SumOfNetwork].signal,buf+6);
			if(network[SumOfNetwork].mode)
				SumOfNetwork++;     
		}
		if(memcmp(buf,"WPA",3)==0)
		{
			network[SumOfNetwork].mode = 1;
		}
		for(k=0;k<SumOfNetwork;k++) if(!strcmp(network[k].SSID,network[SumOfNetwork].SSID)) SumOfNetwork--;
	}
	fclose(fp);
	sprintf(buf,"rm /tmp/dat.dat");
	system(buf);
	return SumOfNetwork+1;
	
}
int Dll_ConnectNetworkNoKey(unsigned char *SSID)
{
	unsigned char buf[100];
	int i=0;

	sprintf(buf,"iwconfig wlan0 essid \"%s\"",SSID);
	system(buf);

	for(i=0;i<15;i++)
	{	
		if(Dll_GetNetworkStatus(buf)==0) return 0;
		sleep(1);
	}
	return -1;
}

int Dll_ConnectNetworkHaveKey(unsigned char *SSID,unsigned char *key)
{
	unsigned char buf[100];
	int i=0;
	
	sprintf(buf,"wpa_passphrase %s \"%s\" > /etc/wpa_supplicant.conf",SSID,key);
	system(buf);
	sleep(5);
	sprintf(buf,"wpa_supplicant -B -iwlan0 -c /etc/wpa_supplicant.conf -Dwext");
	system(buf);
	
	for(i=0;i<15;i++)
	{	
		if(Dll_GetNetworkStatus(buf)==0) return WIFI_CONNECT_SUCCESS;
		sleep(1);
	}
	return WIFI_CONNECT_FAILED;
}


int Dll_SetIP(uchar *ip,uchar *mask,uchar *gateway)
{
	uchar buf[300];

	sprintf(buf,"ifconfig wlan0 %s netmask %s",ip,mask);
	system(buf);

	sprintf(buf,"route del default");
	system(buf);

	sprintf(buf,"route add default gw %s",gateway);
	system(buf);
}

static void KillDhclient()
{
	unsigned char buf[100],pid[10];
	FILE *fp;
	sprintf(buf,"ps -ef | grep udhcpc >/tmp/dat.dat");
	system(buf);
	fp=fopen("/tmp/dat.dat","r");
	while(fscanf(fp,"%s",pid)!=EOF)
	{
		if(pid[0]==0)continue;
		sprintf(buf,"kill %s",pid);
		break;
	}
	fclose(fp);
	system(buf);
}

static void *dhclient(void *arg)
{
	char buf[100];
	sprintf(buf,"udhcpc -i wlan0 -n");
	system(buf);
}

int Dll_Dhcp()
{
	char buf[100];
	FILE *fp;
	pthread_t tid;
	int iret;
	int i;

	iret=pthread_create(&tid, NULL, dhclient, NULL);
	if(iret < 0) {
		return WIFI_GET_DHCP_FAILED;
	}
	for(i=0;i<10;i++){
		sleep(2);
		sprintf(buf,"ifconfig wlan0 >/tmp/dat.dat");
		system(buf);

		fp=fopen("/tmp/dat.dat","r");
		while(fscanf(fp,"%s",buf)!=EOF)
		{
			if(buf[0]==0)continue;
			if(memcmp(buf,"addr",4)==0)
			{
				fclose(fp);
				sprintf(buf,"rm /tmp/dat.dat");
				system(buf);
				pthread_cancel(tid);
				return WIFI_GET_DHCP_SUCCESS;
			}
		}
		fclose(fp);
		sprintf(buf,"rm /tmp/dat.dat");
		system(buf);

	}
	if(i>=10) {
		pthread_cancel(tid);
		return WIFI_GET_DHCP_FAILED;
	}

	return WIFI_GET_DHCP_FAILED;

}

static int getNetworkStatus(unsigned char *network)
{
	FILE *fp;
	char buf[100];
	int i;


	
	fp=fopen("/tmp/dat.dat","r");
	while(fscanf(fp,"%s",buf)!=EOF)
	{
		if(buf[0]==0)continue;
		if( memcmp(buf,"ESSID:\"",7)==0 && buf[7]!='\"')
		{
			memcpy(network,buf+7,strlen(buf)-8);
			network[strlen(buf)-8]=0;
			fclose(fp);
			return 0;
		}
	}
	fclose(fp);
	return -1;
}

int Dll_GetNetworkStatus(unsigned char *network)
{
	BYTE buf[100];
	int iret;
	sprintf(buf,"iwconfig wlan0 >/tmp/dat.dat");
	system(buf);
	iret=getNetworkStatus(buf);
	memcpy(network,buf,strlen(buf));
	sprintf(buf,"rm /tmp/dat.dat");
	system(buf);
	return iret;
}

int Dll_CloseNetwork()
{
	BYTE buf[100];
	BYTE pid[50];
	FILE *fp;
	int flag=0;
	sprintf(buf,"ps -ef | grep wpa_supplicant >/tmp/dat.dat");

	system(buf);
	flag=0;
	fp=fopen("/tmp/dat.dat","r");
	while(fscanf(fp,"%s",pid)!=EOF)
	{
		if(pid[0]==0) continue;
		
		if(flag==0) sprintf(buf,"kill %s",pid);

		flag++;
	}
	fclose(fp);
	
	system(buf);
	sprintf(buf,"ifconfig wlan0 down");
	system(buf);

	sprintf(buf,"ifconfig wlan0 up");
	system(buf);
	
	sprintf(buf,"rm /tmp/dat.dat");
	system(buf);
	return 0;
}

int Dll_SocketOpen(uchar *address,int port,int *sock)
{
    struct hostent *he;
    int sockfd;
    struct sockaddr_in their_addr;
    struct timeval timeout;
    int ret;

    if((he=gethostbyname(address))==NULL)
	{
		return -1;
	}
    if((sockfd=socket(AF_INET,SOCK_STREAM,0))==-1) {
		return 1;
	}
    their_addr.sin_family=AF_INET;

	their_addr.sin_port=htons(port);

	their_addr.sin_addr=*((struct in_addr *)he->h_addr);

	bzero(&(their_addr.sin_zero),8);

    int flags = fcntl(sockfd, F_GETFL, 0);
    ret = fcntl(sockfd, F_SETFL, flags &~O_NONBLOCK);
    if (ret) {
        return 1;
    }
    timeout.tv_sec=1;
    timeout.tv_usec=0;
    ret = setsockopt(sockfd,SOL_SOCKET,SO_SNDTIMEO,(char *)&timeout.tv_sec,sizeof(struct timeval));
    if (ret < 0)
    {
      return 1;
    }
	ret = setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(char *)&timeout.tv_sec,sizeof(struct timeval));
    if (ret < 0)
    {
      return 1;
    }
    if(connect(sockfd,(struct sockaddr *)&their_addr,sizeof(struct sockaddr)) == -1)
	{
        return 1;
    }
    *sock = sockfd;
    return 0;
}

int Dll_SocketClose(int sockfd)
{
	close(sockfd);
	return 0;
}

int Dll_SocketRecv(int sockfd,uchar *buf,int maxLen, int *recvLen,int timeout_sec)
{
	int i;
	int RecvLen=0;
	for (i = 0; i < timeout_sec; i++) {
		if ((*recvLen = read(sockfd, buf, maxLen-RecvLen)) == -1) {
			continue;
		}
		else
		{
			if(*recvLen != 0) buf+=*recvLen;
			RecvLen +=*recvLen;
			if(RecvLen==maxLen){
				*recvLen = RecvLen;
				break;
			}
		}
	}
	return 0;

}

int Dll_SocketSend(int sockfd,uchar *buf,int len)
{
	int i, ret;
	if (ret = send(sockfd, buf, len, 0) == -1)
		return 1;
    for (i = 0; i < 10000; i++);
	return 0;
}


