
#include <sys/types.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <termios.h>
#include <fcntl.h>
#include <pthread.h>
#include <syslog.h>
#include <signal.h>
#include <netdb.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <pthread.h>

#include <unistd.h>
#include <sys/wait.h>

#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <ctype.h>
#include <limits.h>
#include <stdarg.h>
#include <assert.h>
#include <stdint.h>
#include <errno.h>

#include <net/if.h>
#include <linux/if_ether.h>

#include "wifi.h"
//#include "user_sys.h"
//#include "../vosapi.h"
//#include "../inc/vosapi.h"

//#define printf printf

static int giWlanNetNum;

int Dll_WlanListCheck(char *NetName)
{
	FILE *fp;	
	char buf[512], ssid[256];	
	int cnt = 0;
	int id[5];
	if(Dll_WifiOnOff())
		return -1;
	system("wpa_cli -iwlan0 list_networks > ./wifitmp");	
	fp=fopen("./wifitmp","r");
	memset(id, 0, 5);
	fgets(buf,512, fp);
	while(fgets(buf,99, fp)!= NULL)
	{
		memset(ssid, 0, 256);
		sscanf(buf,"%s %s",id, ssid);
		if(strcmp(ssid, NetName) == 0)
		{
			cnt = atoi(id);
			fclose(fp);
			return cnt;
		}
	}
	fclose(fp);
	return -1;
}

void DLL_WifiOpen(void)
{
	if(system("ps  | grep -v grep | grep wpa_supplicant > NULL") != 0)
	{
		system("wpa_supplicant -B -iwlan0 -c /etc/wpa_supplicant.conf -Dwext");
	}
	else
	{
		system("ifconfig wlan0 up");
	}
}
void DLL_WifiClose(void)
{
	system("ifconfig wlan0 down");
}

void DLL_WifiSetIP(unsigned char *ip,unsigned char *mask,unsigned char *gateway)
{
	unsigned char buf[300];

	sprintf(buf,"ifconfig wlan0 %s netmask %s",ip,mask);
	system(buf);

	sprintf(buf,"route del default");
	system(buf);

	sprintf(buf,"route add default gw %s",gateway);
	system(buf);
	
}

static void KillDhclient()
{
	unsigned char buf[100],pid[10];
	FILE *fp;
	sprintf(buf,"ps -ef | grep dhclient >/tmp/dat.dat");
	system(buf);
	fp=fopen("/tmp/dat.dat","r");
	while(fscanf(fp,"%s",pid)!=EOF)
	{
		if(pid[0]==0)continue;
		sprintf(buf,"kill %s",pid);
		break;
	}
	fclose(fp);
	system(buf);
}


static int getNetworkStatus(unsigned char *network)
{
	FILE *fp;
	char buf[100];
	int i;


	
	fp=fopen("/tmp/dat.dat","r");
	while(fscanf(fp,"%s",buf)!=EOF)
	{
		if(buf[0]==0)continue;
		if( memcmp(buf,"ESSID:\"",7)==0 && buf[7]!='\"')
		{
			memcpy(network,buf+7,strlen(buf)-8);
			network[strlen(buf)-8]=0;
			fclose(fp);
			return 0;
		}

	}
	fclose(fp);
	return -1;
}


int Dll_GetNetworkStatus(unsigned char *network)
{
	unsigned char buf[100];
	int iret;
	sprintf(buf,"iwconfig wlan0 >/tmp/dat.dat");
	system(buf);
	iret=getNetworkStatus(buf);
	memcpy(network,buf,strlen(buf));
	sprintf(buf,"rm /tmp/dat.dat");
	system(buf);
	return iret;
}

int DLL_WifiDisConnectNetwork()
{
	unsigned char buf[100];
	unsigned char pid[50];
	FILE *fp;
	int flag=0;

CLOSE_AGAIN:	
	sprintf(buf,"ps -ef | grep wpa_supplicant >/tmp/dat.dat");
	//printf(buf);

	system(buf);
	flag=0;
	fp=fopen("/tmp/dat.dat","r");
	while(fscanf(fp,"%s",pid)!=EOF)
	{
		if(pid[0]==0) continue;
		
		if(flag==0) sprintf(buf,"kill %s",pid);

		flag++;
	}

	if(flag<22){
		sprintf(buf,"wpa_supplicant -B -iwlan0 -c /etc/wpa_supplicant.conf -Dwext");
		//printf(buf);
		system(buf);

		goto CLOSE_AGAIN;
	}
	fclose(fp);
	
	//printf(buf);


	
	system(buf);

	sprintf(buf,"ifconfig wlan0 down");
	//system(buf);

	sprintf(buf,"ifconfig wlan0 up");
	//system(buf);
	
	sprintf(buf,"rm /tmp/dat.dat");
	system(buf);
	return 0;
}


int Dll_WifiOnOff(void)
{
	if(system("ifconfig | grep wlan0 > NULL") == 0)
		return 0;
	else
		return -1;
}
int DLL_WifiScan(T_WLANDEV *gWlanData)
{
	FILE *fp;
	char buf[1024];
	int cnt = 0;
	int start = 0;
	int i = 0;

	if(Dll_WifiOnOff())
		return -1;

	system("wpa_cli scan > ./wifitmp");
	system("wpa_cli scan_results > ./wifitmp");
	fp=fopen("./wifitmp","r");
	
	memset(buf, 0, 1024);
	while(fscanf(fp,"%s",buf)!=EOF)
	{
		if(strcmp("ssid", buf) == 0)
			break;
	}
	while(1)
	{
		memset(buf, 0, 100);
		if(fscanf(fp,"%s",buf)!=EOF)
			strcpy(gWlanData[cnt].bssid, buf);
		else 
			break;

		memset(buf, 0, 100);
		if(fscanf(fp,"%s",buf)!=EOF)
			strcpy(gWlanData[cnt].frequency, buf);
		else 
			break;

		memset(buf, 0, 100);
		if(fscanf(fp,"%s",buf)!=EOF)
			strcpy(gWlanData[cnt].signal, buf);
		else 
			break;

		memset(buf, 0, 100);
		if(fscanf(fp,"%s",buf)!=EOF)
			strcpy(gWlanData[cnt].flags, buf);
		else 
			break;

		memset(buf, 0, 100);
		if(fscanf(fp,"%s",buf)!=EOF)
			strcpy(gWlanData[cnt].ssid, buf);
		else 
			break;

		cnt++;
		if(cnt >50)
			break;
	}
	for(i = 0; i < cnt; i++)
	{
		printf("[%d]%s %s %s\n", i, gWlanData[i].ssid, gWlanData[i].signal, gWlanData[i].flags);
	}
wlanScanOut:	
	fclose(fp);
	return cnt;
}



int Dll_WifiLinkStatus(void)
{
	FILE *fp;	
	char buf[512], status[20];
	
	if(Dll_WifiOnOff())
		return -1;
	system("wpa_cli -iwlan0 status > ./wifitmp");

	fp=fopen("./wifitmp","r");

	memset(buf, 0, 512);
	memset(status, 0, 20);
	while(fscanf(fp,"%s",buf)!=EOF)
	{
		if(strstr(buf, "wpa_state"))
			break;
	}
	strcpy(status, &buf[10]);	
	printf("status:%s\n", status);
	fclose(fp);
	if(strcmp(status, "COMPLETED") == 0)
	{
		return 0;
	}
	else if(strcmp(status, "4WAY_HANDSHAKE") == 0)
	{
		return WLANKEYERR;
	}
	else if(strcmp(status, "DISCONNECTED") == 0)
	{
		return WLANNOUER;
	}
	else if(strcmp(status, "SCANNING") == 0)
	{
		return WLANTIMEOUT;
	}
	else if(strcmp(status, "AUTHENTICATING") == 0)
	{
		return WLANAUTHENTICATING;
	}
	return 1;
}

int DLL_WifiConnectNetwork(T_WLANDEV aWlanDev, char *keyBuf)
{	
	FILE *fp;	
	char addNet[5], wlanCmd[512], status[10];
	int ret, cnt;
	
	if(Dll_WifiOnOff())
		return -1;
	system("wpa_cli -iwlan0 disconnect");

	ret = Dll_WlanListCheck(aWlanDev.ssid);
	if(ret >= 0)
	{
		memset(wlanCmd, 0, 512);
		sprintf(wlanCmd, "wpa_cli -iwlan0 select_network %d", ret);
		printf("%s\n", wlanCmd);
		system(wlanCmd);	
		goto WlanScanStatus;
	}
	
	system("wpa_cli -iwlan0 add_network > ./wifitmp");

	fp=fopen("./wifitmp","r");
	memset(addNet, 0, 5);
	fscanf(fp,"%s",addNet);	
	fclose(fp);
	giWlanNetNum = atoi(addNet);
	memset(wlanCmd, 0, 512);
	sprintf(wlanCmd, "wpa_cli -iwlan0 set_network %d ssid '\"%s\"'", giWlanNetNum, aWlanDev.ssid);
	printf("%s\n", wlanCmd);
	system(wlanCmd);

	if (strstr(aWlanDev.flags, "WPA")||strstr(aWlanDev.flags, "WPA2"))
	{	
		memset(wlanCmd, 0, 512);
		//sprintf(wlanCmd, "wpa_cli -iwlan0 set_network %d psk '\"%s\"'  > ./wifitmp", giWlanNetNum, keyBuf);
		sprintf(wlanCmd, "wpa_cli -iwlan0 set_network %d psk '\"%s\"'", giWlanNetNum, keyBuf);
		printf("%s\n", wlanCmd);
		system(wlanCmd);
	}
	/*else if (strstr(aWlanDev.flags, "WEP"))
	{
		memset(wlanCmd, 0, 512);
		sprintf(wlanCmd, "wpa_cli -iwlan0 set_network %d key_mgmt NONE", giWlanNetNum);
		printf("%s\n", wlanCmd);
		system(wlanCmd);

		memset(wlanCmd, 0, 512);
		sprintf(wlanCmd, "wpa_cli -iwlan0 set_network %d wep_key0 '\"%s\"' > ./wifitmp", giWlanNetNum, keyBuf);
		printf("%s\n", wlanCmd);
		system(wlanCmd);

		fp=fopen("./wifitmp","r");
		memset(status, 0, 10);
		fscanf(fp,"%s",status);			
		fclose(fp);		
		if (strstr(status, "OK") == NULL)
		{
			ret = WLANKEYERR;
			goto WlanConnectErr;
		}	

		memset(wlanCmd, 0, 512);
		sprintf(wlanCmd, "wpa_cli -iwlan0 set_network %d wep_tx_keyidx 0", giWlanNetNum);
		printf("%s\n", wlanCmd);
		system(wlanCmd);
	}*/
	else
	{
		/* OPEN */
		/*
		memset(wlanCmd, 0, 512);
		sprintf(wlanCmd, "wpa_cli -iwlan0 set_network %d key_mgmt NONE", giWlanNetNum);
		printf("%s\n", wlanCmd);
		system(wlanCmd);
		*/
		goto WlanConnectErr;
	}
	memset(wlanCmd, 0, 512);
	sprintf(wlanCmd, "wpa_cli -iwlan0 select_network %d", giWlanNetNum);
	printf("%s\n", wlanCmd);
	system(wlanCmd);	

WlanScanStatus:
	cnt = 0;
	while(1)
	{
		usleep(500*1000);
		ret = Dll_WifiLinkStatus();
		if(ret == 0)
		{
			ret = Dll_WlanDhcp();
			Dll_WlanUpdateConfig();
			break;
		}

		if(cnt++ > 10)
		{
			goto WlanConnectErr;
		}
	}

	
	return ret;
WlanConnectErr:
	memset(wlanCmd, 0, 512);
	sprintf(wlanCmd, "wpa_cli -iwlan0 remove_network %d", giWlanNetNum);
	printf("%s\n", wlanCmd);
	system("wpa_cli -iwlan0 disconnect");
	system(wlanCmd);

	return ret;
	
}


int DLL_WifiGetNetworkStatus(PT_WLANSTATE *paWlanStatus)
{
	FILE *fp;	
	char buf[512];	
	if(Dll_WifiOnOff())
		return -1;
	
	system("wpa_cli -iwlan0 status > ./wifitmp");
	
	fp=fopen("./wifitmp","r");
	memset(paWlanStatus, 0, sizeof(T_WLANSTATE));
	while(fscanf(fp,"%s",buf)!=EOF)
	{
		if(strstr(buf, "ssid="))
			strcpy(paWlanStatus->ssid, &buf[strlen("ssid=")]);
		else if(strstr(buf, "ip_address="))
			strcpy(paWlanStatus->ip, &buf[strlen("ip_address=")]);
		else if(strstr(buf, "key_mgmt="))
			strcpy(paWlanStatus->key_mgmt, &buf[strlen("key_mgmt=")]);
		else if(strstr(buf, "wpa_state="))
			strcpy(paWlanStatus->wpa_state, &buf[strlen("wpa_state=")]);
		else if(strstr(buf, "address="))
			strcpy(paWlanStatus->mac_address, &buf[strlen("address=")]);

		memset(buf, 0, 512);
	}	
	fclose(fp);
	return 0;
}

int DLL_WifiDhcp(void)
{
	int cnt;
	
	if(Dll_WifiOnOff())
		return -1;
	if(system("ps  | grep -v grep | grep udhcpc > NULL") == 0)
		system("killall udhcpc");	
	
	system("udhcpc -i wlan0 &");
	sleep(4);

	return 0;
}

int Dll_WlanUpdateConfig(void)
{

	if(Dll_WifiOnOff())
		return -1;
	system("wpa_cli -iwlan0 save_config");	
	system("sync");
	return 0;
}

T_WLANDEV gWlanDev[50];


#if 0
int SetWifi()
{
	int i,j=0,ret,num;
	unsigned char ucKey;
	unsigned char keyStr[20]={0};
Wifi_Scan:
	Dll_WifiOpen();

	num = Dll_WifiScan(gWlanDev);
	if(num==0) 
		goto Wifi_Scan;
	memcpy(gWlanDev[1].bssid,"00:5a:13:47:a0:84",17);
	memcpy(gWlanDev[1].flags,"[WPA-PSK-CCMP][WPA2-PSK-CCMP][WPS][ESS]",39);
	memcpy(gWlanDev[1].frequency,"2417",4);
	memcpy(gWlanDev[1].signal,"60",2);
	memcpy(gWlanDev[1].ssid,"TP_LINK-unfiou",14);
		ret = Dll_WifiApConnect(gWlanDev[1],"unifou0618");
	return 0;
	
}
int main()
{
	SetWifi();
	return 0;
}

#endif

